import { useState } from "react";

// ─── PALETTE ─────────────────────────────────────────────────────────────────
const C = {
  gold:    "#FFD700",
  cyan:    "#00E5FF",
  green:   "#00FF87",
  pink:    "#FF2D78",
  purple:  "#9B5DE5",
  orange:  "#FF6B00",
  bg:      "#08090E",
  card:    "#10131C",
  card2:   "#161B2C",
  border:  "#1E2540",
  muted:   "#5A6480",
  text:    "#E8EDF8",
};

const GROUP_COLORS = { A: C.cyan, B: C.green, C: C.pink, D: C.purple };

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const GROUPS = {
  A: ["Juventus FC", "Real Madrid", "Bayern Munich", "PSG"],
  B: ["Manchester City", "Inter Milan", "Atletico Madrid", "Borussia Dortmund"],
  C: ["Barcelona", "Liverpool", "Ajax", "Benfica"],
  D: ["Chelsea FC", "Napoli", "Porto", "Shakhtar"]
};

const ROSTERS = {
  "Juventus FC": ["Marco Rossi", "Luca Bianchi", "Andrea Conti", "Paolo Ferretti", "Giovanni Mele"],
  "Real Madrid": ["Carlos Silva", "Diego Ramos", "Fernando López", "Miguel Torres", "Sergio Vidal"],
  "Bayern Munich": ["Klaus Wagner", "Hans Müller", "Stefan Koch", "Peter Braun", "Jürgen Wolf"],
  "PSG": ["Pierre Dubois", "Antoine Moreau", "Julien Bernard", "Nicolas Petit", "Maxime Leroy"],
  "Manchester City": ["Jack Wilson", "Tom Hughes", "Harry Evans", "James Moore", "Oliver Taylor"],
  "Inter Milan": ["Fabio Ricci", "Matteo Gallo", "Simone Esposito", "Lorenzo Costa", "Davide Bruno"],
  "Atletico Madrid": ["Álvaro Jiménez", "Raúl Ruiz", "Pablo Navarro", "Javier Ortega", "Marcos Delgado"],
  "Borussia Dortmund": ["Felix Richter", "Tobias Klein", "Niklas Becker", "Moritz Schulz", "Leon Hoffmann"],
  "Barcelona": ["Xavi Jr.", "Pedro Alves", "Dani Santos", "Marc Pujol", "Jordi Mas"],
  "Liverpool": ["Ryan Scott", "Connor Walsh", "Daniel Murphy", "Patrick Kelly", "Sean Brady"],
  "Ajax": ["Daan Visser", "Lars De Vries", "Niels Bakker", "Sven Meijer", "Ruben Berg"],
  "Benfica": ["Rui Ferreira", "Tiago Pinto", "Nuno Rodrigues", "Bruno Sousa", "Diogo Lopes"],
  "Chelsea FC": ["Ben Carter", "Sam Mitchell", "Josh Clarke", "Luke Walker", "Dan Hall"],
  "Napoli": ["Ciro Russo", "Vincenzo Serra", "Antonio Marino", "Salvatore Greco", "Raffaele Leone"],
  "Porto": ["André Oliveira", "Ricardo Castro", "Gonçalo Alves", "Filipe Gomes", "Nelson Reis"],
  "Shakhtar": ["Andriy Koval", "Dmytro Bondar", "Oleksiy Rudenko", "Vasyl Tkach", "Roman Sydorenko"]
};

const MATCHES_GROUPS = {
  A: [
    { id:"A1", home:"Juventus FC", away:"Real Madrid", homeScore:3, awayScore:1, scorers:{"Juventus FC":["Marco Rossi","Luca Bianchi","Marco Rossi"],"Real Madrid":["Carlos Silva"]}, played:true },
    { id:"A2", home:"Juventus FC", away:"Bayern Munich", homeScore:2, awayScore:2, scorers:{"Juventus FC":["Andrea Conti","Paolo Ferretti"],"Bayern Munich":["Klaus Wagner","Hans Müller"]}, played:true },
    { id:"A3", home:"Juventus FC", away:"PSG", homeScore:1, awayScore:0, scorers:{"Juventus FC":["Luca Bianchi"],"PSG":[]}, played:true },
    { id:"A4", home:"Real Madrid", away:"Bayern Munich", homeScore:0, awayScore:1, scorers:{"Real Madrid":[],"Bayern Munich":["Stefan Koch"]}, played:true },
    { id:"A5", home:"Real Madrid", away:"PSG", homeScore:2, awayScore:3, scorers:{"Real Madrid":["Diego Ramos","Fernando López"],"PSG":["Pierre Dubois","Antoine Moreau","Julien Bernard"]}, played:true },
    { id:"A6", home:"Bayern Munich", away:"PSG", homeScore:null, awayScore:null, scorers:{}, played:false }
  ],
  B: [
    { id:"B1", home:"Manchester City", away:"Inter Milan", homeScore:2, awayScore:1, scorers:{"Manchester City":["Jack Wilson","Tom Hughes"],"Inter Milan":["Fabio Ricci"]}, played:true },
    { id:"B2", home:"Manchester City", away:"Atletico Madrid", homeScore:1, awayScore:1, scorers:{"Manchester City":["Harry Evans"],"Atletico Madrid":["Álvaro Jiménez"]}, played:true },
    { id:"B3", home:"Manchester City", away:"Borussia Dortmund", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"B4", home:"Inter Milan", away:"Atletico Madrid", homeScore:3, awayScore:0, scorers:{"Inter Milan":["Matteo Gallo","Simone Esposito","Lorenzo Costa"],"Atletico Madrid":[]}, played:true },
    { id:"B5", home:"Inter Milan", away:"Borussia Dortmund", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"B6", home:"Atletico Madrid", away:"Borussia Dortmund", homeScore:null, awayScore:null, scorers:{}, played:false }
  ],
  C: [
    { id:"C1", home:"Barcelona", away:"Liverpool", homeScore:2, awayScore:2, scorers:{"Barcelona":["Xavi Jr.","Pedro Alves"],"Liverpool":["Ryan Scott","Connor Walsh"]}, played:true },
    { id:"C2", home:"Barcelona", away:"Ajax", homeScore:4, awayScore:1, scorers:{"Barcelona":["Dani Santos","Marc Pujol","Jordi Mas","Xavi Jr."],"Ajax":["Daan Visser"]}, played:true },
    { id:"C3", home:"Barcelona", away:"Benfica", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"C4", home:"Liverpool", away:"Ajax", homeScore:1, awayScore:0, scorers:{"Liverpool":["Daniel Murphy"],"Ajax":[]}, played:true },
    { id:"C5", home:"Liverpool", away:"Benfica", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"C6", home:"Ajax", away:"Benfica", homeScore:null, awayScore:null, scorers:{}, played:false }
  ],
  D: [
    { id:"D1", home:"Chelsea FC", away:"Napoli", homeScore:1, awayScore:2, scorers:{"Chelsea FC":["Ben Carter"],"Napoli":["Ciro Russo","Vincenzo Serra"]}, played:true },
    { id:"D2", home:"Chelsea FC", away:"Porto", homeScore:0, awayScore:0, scorers:{"Chelsea FC":[],"Porto":[]}, played:true },
    { id:"D3", home:"Chelsea FC", away:"Shakhtar", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"D4", home:"Napoli", away:"Porto", homeScore:2, awayScore:1, scorers:{"Napoli":["Antonio Marino","Salvatore Greco"],"Porto":["André Oliveira"]}, played:true },
    { id:"D5", home:"Napoli", away:"Shakhtar", homeScore:null, awayScore:null, scorers:{}, played:false },
    { id:"D6", home:"Porto", away:"Shakhtar", homeScore:null, awayScore:null, scorers:{}, played:false }
  ]
};

const KNOCKOUT = {
  quarters: [
    { id:"Q1", home:"Juventus FC", away:"Inter Milan", homeScore:2, awayScore:1, played:true },
    { id:"Q2", home:"PSG", away:"Manchester City", homeScore:null, awayScore:null, played:false },
    { id:"Q3", home:"Barcelona", away:"Chelsea FC", homeScore:null, awayScore:null, played:false },
    { id:"Q4", home:"Liverpool", away:"Napoli", homeScore:null, awayScore:null, played:false }
  ],
  semis: [
    { id:"S1", home:"Juventus FC", away:"TBD", homeScore:null, awayScore:null, played:false },
    { id:"S2", home:"TBD", away:"TBD", homeScore:null, awayScore:null, played:false }
  ],
  final: { id:"F1", home:"TBD", away:"TBD", homeScore:null, awayScore:null, played:false }
};

// ─── UTILS ────────────────────────────────────────────────────────────────────
function computeStandings(g) {
  const teams = GROUPS[g];
  const matches = MATCHES_GROUPS[g];
  const t = {};
  teams.forEach(n => { t[n] = { team:n, played:0, won:0, drawn:0, lost:0, gf:0, ga:0, gd:0, pts:0 }; });
  matches.filter(m => m.played).forEach(m => {
    const h = t[m.home], a = t[m.away];
    h.played++; a.played++;
    h.gf += m.homeScore; h.ga += m.awayScore;
    a.gf += m.awayScore; a.ga += m.homeScore;
    if (m.homeScore > m.awayScore) { h.won++; h.pts+=3; a.lost++; }
    else if (m.homeScore < m.awayScore) { a.won++; a.pts+=3; h.lost++; }
    else { h.drawn++; a.drawn++; h.pts++; a.pts++; }
    h.gd = h.gf-h.ga; a.gd = a.gf-a.ga;
  });
  return Object.values(t).sort((a,b) => b.pts-a.pts || b.gd-a.gd || b.gf-a.gf);
}

function computeScorers() {
  const tally = {};
  Object.values(MATCHES_GROUPS).forEach(group => {
    group.filter(m => m.played).forEach(m => {
      Object.values(m.scorers).forEach(players => {
        players.forEach(p => { tally[p] = (tally[p]||0)+1; });
      });
    });
  });
  return Object.entries(tally).map(([name,goals])=>({name,goals})).sort((a,b)=>b.goals-a.goals);
}

// ─── SHARED COMPONENTS ────────────────────────────────────────────────────────

function GlowBadge({ children, color = C.gold }) {
  return (
    <span style={{
      background: color+"28", border:`1px solid ${color}60`, color,
      padding:"3px 10px", borderRadius:20, fontSize:10,
      fontFamily:"'Oswald',sans-serif", letterSpacing:2, textTransform:"uppercase",
      boxShadow:`0 0 10px ${color}40`
    }}>{children}</span>
  );
}

function SectionTitle({ children, color = C.gold }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10, margin:"22px 0 14px" }}>
      <div style={{ flex:1, height:1, background:`linear-gradient(90deg, ${color}80, transparent)` }} />
      <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:14, letterSpacing:4, color, whiteSpace:"nowrap" }}>{children}</span>
      <div style={{ flex:1, height:1, background:`linear-gradient(270deg, ${color}80, transparent)` }} />
    </div>
  );
}

function ScoreCard({ home, away, hScore, aScore, played, accentColor = C.gold }) {
  return (
    <div style={{
      background: C.card,
      border:`1px solid ${played ? accentColor+"50" : C.border}`,
      borderRadius:12, padding:"14px 16px", marginBottom:10,
      position:"relative", overflow:"hidden"
    }}>
      <div style={{ position:"absolute", top:0, left:0, right:0, height:3,
        background: played ? `linear-gradient(90deg, ${accentColor}, ${C.cyan})` : C.border }} />
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ flex:1, fontFamily:"'Oswald',sans-serif", fontSize:14, color:C.text, textAlign:"right", lineHeight:1.2 }}>{home}</span>
        <div style={{ display:"flex", gap:6, alignItems:"center", flexShrink:0 }}>
          <div style={{
            background: played ? `linear-gradient(135deg, ${accentColor}, ${C.orange})` : C.card2,
            color: played ? "#000" : C.muted,
            fontFamily:"'Bebas Neue',sans-serif", fontSize:26,
            minWidth:38, textAlign:"center", borderRadius:8, padding:"4px 6px",
            boxShadow: played ? `0 0 16px ${accentColor}60` : "none"
          }}>{played ? hScore : "-"}</div>
          <span style={{ color:C.muted, fontSize:11, fontFamily:"'Oswald',sans-serif" }}>VS</span>
          <div style={{
            background: played ? `linear-gradient(135deg, ${accentColor}, ${C.orange})` : C.card2,
            color: played ? "#000" : C.muted,
            fontFamily:"'Bebas Neue',sans-serif", fontSize:26,
            minWidth:38, textAlign:"center", borderRadius:8, padding:"4px 6px",
            boxShadow: played ? `0 0 16px ${accentColor}60` : "none"
          }}>{played ? aScore : "-"}</div>
        </div>
        <span style={{ flex:1, fontFamily:"'Oswald',sans-serif", fontSize:14, color:C.text, lineHeight:1.2 }}>{away}</span>
      </div>
      {!played && (
        <div style={{ textAlign:"center", marginTop:8 }}>
          <GlowBadge color={C.muted}>In programma</GlowBadge>
        </div>
      )}
    </div>
  );
}

function GroupTab({ label, active, color, onClick }) {
  return (
    <button onClick={onClick} style={{
      flex:1, padding:"10px 0", borderRadius:10, border:"none", cursor:"pointer",
      background: active ? `linear-gradient(135deg, ${color}, ${color}88)` : C.card2,
      color: active ? "#000" : C.muted,
      fontFamily:"'Bebas Neue',sans-serif", fontSize:20, letterSpacing:2,
      boxShadow: active ? `0 4px 20px ${color}60` : "none",
      outline: active ? "none" : `1px solid ${C.border}`,
      transition:"all 0.2s"
    }}>Girone {label}</button>
  );
}

// ─── PAGES ────────────────────────────────────────────────────────────────────

function HomePage() {
  const scorers = computeScorers().slice(0,3);
  const totalGoals = Object.values(MATCHES_GROUPS).flat().filter(m=>m.played).reduce((a,m)=>a+m.homeScore+m.awayScore,0);
  const playedCount = Object.values(MATCHES_GROUPS).flat().filter(m=>m.played).length;

  return (
    <div>
      {/* Hero */}
      <div style={{
        textAlign:"center", padding:"44px 20px 32px",
        background:`radial-gradient(ellipse at 50% -10%, ${C.cyan}18 0%, ${C.purple}10 40%, transparent 70%)`,
        borderBottom:`1px solid ${C.border}`, position:"relative", overflow:"hidden"
      }}>
        <div style={{
          position:"absolute", top:-60, left:"50%", transform:"translateX(-50%)",
          width:300, height:300, borderRadius:"50%",
          background:`radial-gradient(${C.cyan}15, transparent 70%)`,
          pointerEvents:"none"
        }} />
        <div style={{ fontSize:11, letterSpacing:5, color:C.cyan, fontFamily:"'Oswald',sans-serif", marginBottom:6, textTransform:"uppercase" }}>
          ⚽ Stagione 2025
        </div>
        <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:58, lineHeight:1, letterSpacing:5,
          background:`linear-gradient(135deg, #fff 0%, ${C.cyan} 50%, ${C.gold} 100%)`,
          WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
          AZZURRA
        </div>
        <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:26, letterSpacing:6,
          background:`linear-gradient(90deg, ${C.gold}, ${C.orange})`,
          WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
          CHAMPIONS CUP
        </div>
        <div style={{ marginTop:16, display:"flex", gap:8, justifyContent:"center", flexWrap:"wrap" }}>
          <GlowBadge color={C.cyan}>16 squadre</GlowBadge>
          <GlowBadge color={C.gold}>3 giorni</GlowBadge>
          <GlowBadge color={C.green}>31 partite</GlowBadge>
        </div>
      </div>

      {/* Stats */}
      <div style={{ padding:"20px 16px 0" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10 }}>
          {[
            { label:"Partite giocate", value:playedCount, color:C.cyan },
            { label:"Goal totali", value:totalGoals, color:C.green },
            { label:"Marcatori", value:computeScorers().length, color:C.pink }
          ].map(s => (
            <div key={s.label} style={{
              background:`linear-gradient(135deg, ${s.color}18, ${C.card})`,
              border:`1px solid ${s.color}40`, borderRadius:12, padding:"16px 8px", textAlign:"center"
            }}>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:38, color:s.color,
                lineHeight:1, textShadow:`0 0 20px ${s.color}` }}>{s.value}</div>
              <div style={{ fontSize:9, color:C.muted, marginTop:5, fontFamily:"'Oswald',sans-serif",
                letterSpacing:1, textTransform:"uppercase", lineHeight:1.3 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Top 3 */}
      <div style={{ padding:"0 16px" }}>
        <SectionTitle color={C.gold}>🥅 Top Marcatori</SectionTitle>
        {scorers.map((s,i) => {
          const colors = [C.gold, "#C0C0C0", "#CD7F32"];
          const medals = ["🥇","🥈","🥉"];
          return (
            <div key={s.name} style={{
              display:"flex", alignItems:"center", gap:12,
              background: i===0 ? `linear-gradient(135deg, ${C.gold}18, ${C.card})` : C.card,
              border:`1px solid ${i===0 ? C.gold+"50" : C.border}`,
              borderRadius:12, padding:"12px 16px", marginBottom:8,
              boxShadow: i===0 ? `0 4px 24px ${C.gold}25` : "none"
            }}>
              <span style={{ fontSize:24, minWidth:32 }}>{medals[i]}</span>
              <span style={{ flex:1, fontFamily:"'Oswald',sans-serif", fontSize:16, color:C.text }}>{s.name}</span>
              <div style={{ display:"flex", alignItems:"center", gap:4 }}>
                <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:28, color:colors[i],
                  textShadow:`0 0 12px ${colors[i]}` }}>{s.goals}</span>
                <span style={{ fontSize:16 }}>⚽</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Phases */}
      <div style={{ padding:"0 16px 16px" }}>
        <SectionTitle color={C.cyan}>📅 Fasi del torneo</SectionTitle>
        {[
          { day:"Giorno 1", label:"Fase a Gironi — Round 1", status:"done", color:C.green },
          { day:"Giorno 2", label:"Fase a Gironi — Round 2", status:"live", color:C.gold },
          { day:"Giorno 3", label:"Quarti → Semifinali → Finale", status:"upcoming", color:C.muted }
        ].map(f => (
          <div key={f.day} style={{
            display:"flex", alignItems:"center", gap:14,
            background: f.status==="live" ? `${C.gold}12` : C.card,
            border:`1px solid ${f.status==="live" ? C.gold+"50" : C.border}`,
            borderRadius:10, padding:"12px 16px", marginBottom:8
          }}>
            <div style={{ width:12, height:12, borderRadius:"50%", background:f.color,
              boxShadow:`0 0 10px ${f.color}`, flexShrink:0 }} />
            <div style={{ flex:1 }}>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, color:C.text, letterSpacing:2 }}>{f.day}</div>
              <div style={{ fontSize:12, color:C.muted }}>{f.label}</div>
            </div>
            {f.status==="live" && <GlowBadge color={C.gold}>IN CORSO</GlowBadge>}
            {f.status==="done" && <GlowBadge color={C.green}>FATTO</GlowBadge>}
          </div>
        ))}
      </div>
    </div>
  );
}

function GroupsPage() {
  const [active, setActive] = useState("A");
  const color = GROUP_COLORS[active];
  const standings = computeStandings(active);

  return (
    <div style={{ padding:"0 16px 16px" }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, letterSpacing:4, textAlign:"center",
        marginTop:20, marginBottom:16,
        background:`linear-gradient(90deg, ${C.cyan}, ${C.gold})`,
        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
        CLASSIFICHE GIRONI
      </div>
      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {["A","B","C","D"].map(g => (
          <GroupTab key={g} label={g} active={active===g} color={GROUP_COLORS[g]} onClick={()=>setActive(g)} />
        ))}
      </div>

      {/* Table */}
      <div style={{ background:C.card, border:`1px solid ${color}40`, borderRadius:12, overflow:"hidden",
        boxShadow:`0 4px 30px ${color}20` }}>
        <div style={{ height:3, background:`linear-gradient(90deg, ${color}, ${C.cyan})` }} />
        <div style={{ display:"grid", gridTemplateColumns:"22px 1fr 26px 26px 26px 26px 26px 26px 30px",
          gap:4, padding:"10px 12px", background:C.card2 }}>
          {["#","Squadra","G","V","P","S","GF","GA","Pts"].map(h => (
            <span key={h} style={{ fontFamily:"'Oswald',sans-serif", fontSize:11, color:C.muted,
              textAlign:"center", letterSpacing:1 }}>{h}</span>
          ))}
        </div>
        {standings.map((row,i) => (
          <div key={row.team} style={{
            display:"grid", gridTemplateColumns:"22px 1fr 26px 26px 26px 26px 26px 26px 30px",
            gap:4, padding:"12px 12px", alignItems:"center",
            borderTop:`1px solid ${C.border}`,
            background: i<2 ? `${color}0A` : "transparent"
          }}>
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:16,
              color: i<2 ? color : C.muted, textAlign:"center" }}>{i+1}</span>
            <span style={{ fontFamily:"'Oswald',sans-serif", fontSize:12, color:C.text,
              whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{row.team}</span>
            {[row.played,row.won,row.drawn,row.lost,row.gf,row.ga].map((v,j) => (
              <span key={j} style={{ fontFamily:"'Oswald',sans-serif", fontSize:13,
                color:C.muted, textAlign:"center" }}>{v}</span>
            ))}
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:20,
              color: i<2 ? color : C.text, textAlign:"center",
              textShadow: i<2 ? `0 0 10px ${color}` : "none" }}>{row.pts}</span>
          </div>
        ))}
      </div>
      <div style={{ textAlign:"center", marginTop:10, fontSize:11, color:C.muted }}>
        Le prime 2 si qualificano ai quarti di finale
      </div>
    </div>
  );
}

function ResultsPage() {
  const [active, setActive] = useState("A");
  const color = GROUP_COLORS[active];

  return (
    <div style={{ padding:"0 16px 16px" }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, letterSpacing:4, textAlign:"center",
        marginTop:20, marginBottom:16,
        background:`linear-gradient(90deg, ${C.pink}, ${C.orange})`,
        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
        RISULTATI
      </div>
      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {["A","B","C","D"].map(g => (
          <GroupTab key={g} label={g} active={active===g} color={GROUP_COLORS[g]} onClick={()=>setActive(g)} />
        ))}
      </div>
      {MATCHES_GROUPS[active].map(m => (
        <div key={m.id}>
          <ScoreCard home={m.home} away={m.away} hScore={m.homeScore} aScore={m.awayScore} played={m.played} accentColor={color} />
          {m.played && Object.values(m.scorers).some(a=>a.length>0) && (
            <div style={{ background:C.bg, border:`1px solid ${C.border}`, borderRadius:"0 0 10px 10px",
              padding:"8px 14px", marginTop:-12, marginBottom:10 }}>
              {Object.entries(m.scorers).map(([team,players]) => players.length>0 && (
                <div key={team} style={{ fontSize:12, color:C.muted, marginBottom:2 }}>
                  <span style={{ color, fontFamily:"'Oswald',sans-serif" }}>{team}:</span> {players.join(", ")}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function ScorersPage() {
  const scorers = computeScorers();
  const gradients = [
    `linear-gradient(135deg, ${C.gold}, ${C.orange})`,
    `linear-gradient(135deg, #C0C0C0, #888)`,
    `linear-gradient(135deg, #CD7F32, #8B4513)`,
  ];

  return (
    <div style={{ padding:"0 16px 16px" }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, letterSpacing:4, textAlign:"center",
        marginTop:20, marginBottom:16,
        background:`linear-gradient(90deg, ${C.green}, ${C.cyan})`,
        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
        CAPOCANNONIERI
      </div>
      {scorers.map((s,i) => {
        const isTop3 = i < 3;
        const bg = isTop3 ? gradients[i] : C.card;
        return (
          <div key={s.name} style={{
            display:"flex", alignItems:"center", gap:14,
            background: isTop3 ? C.card : C.card,
            border:`1px solid ${isTop3 ? (i===0?C.gold:i===1?"#C0C0C0":"#CD7F32")+"60" : C.border}`,
            borderRadius:12, padding:"14px 16px", marginBottom:8,
            boxShadow: i===0 ? `0 6px 30px ${C.gold}30` : "none",
            position:"relative", overflow:"hidden"
          }}>
            {isTop3 && <div style={{ position:"absolute", left:0, top:0, bottom:0, width:4,
              background:bg }} />}
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize: isTop3 ? 28 : 18,
              minWidth:38, textAlign:"center",
              background: isTop3 ? bg : "none",
              WebkitBackgroundClip: isTop3 ? "text" : "initial",
              WebkitTextFillColor: isTop3 ? "transparent" : C.muted,
              color: isTop3 ? "transparent" : C.muted
            }}>{isTop3 ? ["🥇","🥈","🥉"][i] : i+1}</span>
            <span style={{ flex:1, fontFamily:"'Oswald',sans-serif", fontSize:16, color:C.text }}>{s.name}</span>
            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
              <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30,
                background: isTop3 ? bg : "none",
                WebkitBackgroundClip: isTop3 ? "text" : "initial",
                WebkitTextFillColor: isTop3 ? "transparent" : C.text,
                color: isTop3 ? "transparent" : C.text
              }}>{s.goals}</span>
              <span>⚽</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function RostersPage() {
  const [activeTeam, setActiveTeam] = useState(null);

  return (
    <div style={{ padding:"0 16px 16px" }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, letterSpacing:4, textAlign:"center",
        marginTop:20, marginBottom:16,
        background:`linear-gradient(90deg, ${C.purple}, ${C.pink})`,
        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
        DISTINTE SQUADRE
      </div>

      {activeTeam ? (
        <div>
          <button onClick={()=>setActiveTeam(null)} style={{
            background:`linear-gradient(135deg, ${C.purple}30, ${C.card2})`,
            border:`1px solid ${C.purple}50`, color:C.purple,
            padding:"8px 16px", borderRadius:8, cursor:"pointer",
            fontFamily:"'Oswald',sans-serif", fontSize:13, letterSpacing:1, marginBottom:16
          }}>← TORNA ALLA LISTA</button>
          <div style={{ background:`linear-gradient(135deg, ${C.purple}15, ${C.card})`,
            border:`1px solid ${C.purple}40`, borderRadius:12, padding:20,
            boxShadow:`0 4px 30px ${C.purple}20` }}>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:28, letterSpacing:3,
              background:`linear-gradient(90deg, ${C.purple}, ${C.pink})`,
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", marginBottom:16 }}>{activeTeam}</div>
            {ROSTERS[activeTeam]?.map((player,i) => (
              <div key={player} style={{ display:"flex", alignItems:"center", gap:14,
                padding:"11px 0", borderBottom:`1px solid ${C.border}` }}>
                <div style={{ width:28, height:28, borderRadius:"50%",
                  background:`linear-gradient(135deg, ${C.purple}, ${C.pink})`,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontFamily:"'Bebas Neue',sans-serif", fontSize:14, color:"#fff", flexShrink:0 }}>{i+1}</div>
                <span style={{ fontFamily:"'Oswald',sans-serif", fontSize:15, color:C.text }}>{player}</span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        Object.entries(GROUPS).map(([g,teams]) => {
          const gc = GROUP_COLORS[g];
          return (
            <div key={g} style={{ marginBottom:22 }}>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", letterSpacing:4, fontSize:13,
                color:gc, marginBottom:10, textTransform:"uppercase",
                textShadow:`0 0 10px ${gc}` }}>● Girone {g}</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                {teams.map(team => (
                  <button key={team} onClick={()=>setActiveTeam(team)} style={{
                    background:`linear-gradient(135deg, ${gc}12, ${C.card})`,
                    border:`1px solid ${gc}40`, borderRadius:12,
                    padding:"16px 12px", cursor:"pointer", textAlign:"left",
                    transition:"all 0.2s"
                  }}>
                    <div style={{ fontSize:22, marginBottom:6 }}>👕</div>
                    <div style={{ fontFamily:"'Oswald',sans-serif", fontSize:13, color:C.text, marginBottom:4 }}>{team}</div>
                    <div style={{ fontSize:11, color:gc }}>{ROSTERS[team]?.length||0} giocatori →</div>
                  </button>
                ))}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

function BracketPage() {
  return (
    <div style={{ padding:"0 16px 16px" }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, letterSpacing:4, textAlign:"center",
        marginTop:20, marginBottom:16,
        background:`linear-gradient(90deg, ${C.gold}, ${C.orange}, ${C.pink})`,
        WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
        TABELLONE FINALE
      </div>

      <SectionTitle color={C.cyan}>⚔️ Quarti di finale</SectionTitle>
      {KNOCKOUT.quarters.map(m => (
        <ScoreCard key={m.id} home={m.home} away={m.away} hScore={m.homeScore} aScore={m.awayScore} played={m.played} accentColor={C.cyan} />
      ))}

      <SectionTitle color={C.pink}>🔥 Semifinali</SectionTitle>
      {KNOCKOUT.semis.map(m => (
        <ScoreCard key={m.id} home={m.home} away={m.away} hScore={m.homeScore} aScore={m.awayScore} played={m.played} accentColor={C.pink} />
      ))}

      <SectionTitle color={C.gold}>🏆 Finale</SectionTitle>
      <div style={{ position:"relative", padding:3, borderRadius:14,
        background:`linear-gradient(135deg, ${C.gold}, ${C.orange}, ${C.pink})`,
        boxShadow:`0 8px 40px ${C.gold}40` }}>
        <div style={{ background:C.bg, borderRadius:12 }}>
          <ScoreCard home={KNOCKOUT.final.home} away={KNOCKOUT.final.away}
            hScore={KNOCKOUT.final.homeScore} aScore={KNOCKOUT.final.awayScore}
            played={KNOCKOUT.final.played} accentColor={C.gold} />
        </div>
      </div>
    </div>
  );
}

// ─── NAV ─────────────────────────────────────────────────────────────────────
const NAV = [
  { id:"home",    icon:"⚽", label:"Home",      color:C.cyan },
  { id:"groups",  icon:"📊", label:"Gironi",    color:C.green },
  { id:"results", icon:"🏟️", label:"Risultati", color:C.pink },
  { id:"scorers", icon:"🥅", label:"Marcatori", color:C.gold },
  { id:"rosters", icon:"👥", label:"Distinte",  color:C.purple },
  { id:"bracket", icon:"🏆", label:"Tabellone", color:C.orange },
];

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("home");
  const activeColor = NAV.find(n=>n.id===page)?.color || C.gold;

  const pages = {
    home:<HomePage/>, groups:<GroupsPage/>, results:<ResultsPage/>,
    scorers:<ScorersPage/>, rosters:<RostersPage/>, bracket:<BracketPage/>
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Oswald:wght@300;400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:${C.bg};color:${C.text};font-family:'Oswald',sans-serif;}
        ::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${C.border};border-radius:4px;}
        button{-webkit-tap-highlight-color:transparent;}
      `}</style>

      <div style={{ maxWidth:480, margin:"0 auto", minHeight:"100vh", background:C.bg }}>
        {/* Header */}
        <div style={{
          position:"sticky", top:0, zIndex:50,
          background:`rgba(8,9,14,0.94)`, backdropFilter:"blur(16px)",
          borderBottom:`1px solid ${activeColor}30`,
          padding:"12px 18px", display:"flex", alignItems:"center", justifyContent:"space-between",
          boxShadow:`0 2px 20px ${activeColor}15`
        }}>
          <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, letterSpacing:4 }}>
            <span style={{ background:`linear-gradient(90deg, #fff, ${C.cyan})`,
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>AZZURRA </span>
            <span style={{ background:`linear-gradient(90deg, ${C.gold}, ${C.orange})`,
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>CC</span>
          </div>
          <GlowBadge color={C.green}>🟢 LIVE</GlowBadge>
        </div>

        <div style={{ paddingBottom:80 }}>{pages[page]}</div>

        {/* Bottom Nav */}
        <div style={{
          position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
          width:"100%", maxWidth:480,
          background:`rgba(8,9,14,0.97)`, backdropFilter:"blur(16px)",
          borderTop:`1px solid ${activeColor}30`,
          display:"flex", padding:"8px 2px 14px"
        }}>
          {NAV.map(item => {
            const isActive = page===item.id;
            return (
              <button key={item.id} onClick={()=>setPage(item.id)} style={{
                flex:1, display:"flex", flexDirection:"column", alignItems:"center",
                gap:3, background:"none", border:"none", cursor:"pointer", padding:"4px 0"
              }}>
                <div style={{
                  width:36, height:36, borderRadius:10,
                  background: isActive ? `linear-gradient(135deg, ${item.color}30, ${item.color}15)` : "transparent",
                  border: isActive ? `1px solid ${item.color}60` : "1px solid transparent",
                  display:"flex", alignItems:"center", justifyContent:"center", fontSize:18,
                  boxShadow: isActive ? `0 0 16px ${item.color}40` : "none",
                  transition:"all 0.2s"
                }}>{item.icon}</div>
                <span style={{
                  fontFamily:"'Oswald',sans-serif", fontSize:9, letterSpacing:1,
                  color: isActive ? item.color : C.muted, textTransform:"uppercase",
                  textShadow: isActive ? `0 0 8px ${item.color}` : "none"
                }}>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}
